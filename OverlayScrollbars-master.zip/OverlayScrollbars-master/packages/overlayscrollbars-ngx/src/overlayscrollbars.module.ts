import { NgModule } from '@angular/core';
import { OverlayScrollbarsComponent } from './overlayscrollbars.component';

@NgModule({
    imports: [],
    declarations: [OverlayScrollbarsComponent],
    exports: [OverlayScrollbarsComponent]
})
export class OverlayscrollbarsModule { }
